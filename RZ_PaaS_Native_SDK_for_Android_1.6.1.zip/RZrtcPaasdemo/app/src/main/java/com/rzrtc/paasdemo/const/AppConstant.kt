package com.rzrtc.paasdemo.const

object AppConstant {
    //填写对应相关的appid
    const val DEFAULT_APPID="

    const val devEnv="{\"api\":\"https://api.rzrtc.com\",\"log\":\"http://data-center-dev.duobeiyun.com\"}"
    const val CHANNEL_ID = "channelId"
    const val USER_ID = "userId"


}