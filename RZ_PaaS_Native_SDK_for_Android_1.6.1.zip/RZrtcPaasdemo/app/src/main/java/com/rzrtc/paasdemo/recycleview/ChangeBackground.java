package com.rzrtc.paasdemo.recycleview;

import android.view.View;

public interface ChangeBackground {
    void change(View view);
}
