package com.rzrtc.paasdemo.recycleview;

public abstract class ResType {

    public abstract int getResId();
}
