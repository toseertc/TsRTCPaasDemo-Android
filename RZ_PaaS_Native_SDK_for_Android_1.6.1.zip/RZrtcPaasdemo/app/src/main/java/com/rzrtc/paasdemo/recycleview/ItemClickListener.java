package com.rzrtc.paasdemo.recycleview;

public interface ItemClickListener<Data>  {
    void onClick(Data data, int position);
}
