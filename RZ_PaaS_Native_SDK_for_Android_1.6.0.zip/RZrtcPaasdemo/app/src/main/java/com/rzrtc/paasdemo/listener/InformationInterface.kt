package com.rzrtc.paasdemo.listener

import com.rz.paas.test.pass_sdk.middle.MiddleEngineCallback

open class InformationInterface() : MiddleEngineCallback() {

}